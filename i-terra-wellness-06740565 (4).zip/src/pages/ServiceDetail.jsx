import React from "react";

export default function ServiceDetail() {
  return (
    <div
      className="service-detail-root"
      style={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: "transparent",
      }}
    >
      <p style={{ color: "var(--champagne)", fontFamily: "serif" }}>
        ServiceDetail page - awaiting structure
      </p>
    </div>
  );
}